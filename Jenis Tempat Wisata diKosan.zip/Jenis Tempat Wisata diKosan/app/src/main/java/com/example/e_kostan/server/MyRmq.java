package com.example.e_kostan.server;

public interface MyRmq {
    void Berhasil(String message);
    void Gagal();
}
