package com.example.e_kostan.Menu;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.e_kostan.R;

public class DetailPesan extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_pesan);
    }
}